#include <stdio.h>
#include <graphics.h>

void midpoint(int x0, int y0, int r) {
	float p = 5/4 - r;
	putpixel(x0, y0, WHITE);
	float x = 0, y = (int)r;
	while(x < y) {
		x++;
		if(p > 0) {
			y--;
			p = p + 2*x - 2*y + 1;
		}	
		else 
			p += 2*x + 1;
		putpixel((int)x + x0, (int)y + y0, WHITE);
		putpixel((int)y + y0, (int)x + x0, WHITE);
		putpixel((int)x + x0, -(int)y + y0, WHITE);
		putpixel(-(int)y + y0, (int)x + x0, WHITE);
		putpixel(-(int)x + x0, (int)y + y0, WHITE);
		putpixel((int)y + y0, -(int)x + x0, WHITE);
		putpixel(-(int)x + x0, -(int)y + y0, WHITE);
		putpixel(-(int)y + y0, -(int)x + x0, WHITE); 
	}
	getch();
}

int main() {
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");
	midpoint(100, 100, 50);
	getch();
	return 0;
}
