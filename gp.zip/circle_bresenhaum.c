#include <stdio.h>
#include <graphics.h>

void bresenhaum(int x, int y, int p, int q, int r, int d) {
	putpixel(x + p, y + q, WHITE);
	putpixel(x - p, y - q, WHITE);
	putpixel(x - p, y + q, WHITE);
	putpixel(x + p, y - q, WHITE);
	putpixel(x - q, y + p, WHITE);
	putpixel(x + q, y - p, WHITE);
	putpixel(x + q, y + p, WHITE);
	putpixel(x - q, y - p, WHITE); 
}

int main() {
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");
	int r = 40, x = 50, y = 50, p = 0, q = r, d = 3-2*r;  
	while(p <= q) {
	bresenhaum(x, y, p, q, r, d);
		p++;
		if(d < 0)
		d = d + 4*p + 6;
		else {
			q--;
			d = d + 4*(p - q) + 10;	
		}
		
	}
	bresenhaum(x, y, p, q, r, d);
	getch();
	return 0;
}
