#include <stdio.h>
#include <graphics.h>

int main() {
	int x1=10, y1=10, x2=100, y2=100, m1=3, m2=4;
	double u, x, y;	
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");

	for(u = 0; u <= 1; u += 0.001) {
		x = (2*u*u*u-3*u*u+1)*x1 + (-2*u*u*u+3*u*u)*x2 + (u*u*u-2*u*u+u)*m1*x1 + (u*u*u-u*u)*m2*x2;
		y = (2*u*u*u-3*u*u+1)*y1 + (-2*u*u*u+3*u*u)*y2 + (u*u*u-2*u*u+u)*m1*x1 + (u*u*u-u*u)*m2*x2;
		putpixel(x, y, 15);	
		delay(10);	
	}

	getch();
	closegraph();

	return 0;
}
