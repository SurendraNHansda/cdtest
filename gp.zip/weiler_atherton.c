#include<stdio.h>
#include <graphics.h>

void weiler_polygon_clipping();

void main() { 
	int gd = DETECT, gm;
	initgraph(&gd,&gm,"");
	cleardevice();
	setbkcolor(6);
	weiler_polygon_clipping();
	cleardevice();
	setbkcolor(2);
	getch();
	closegraph();
}

void weiler_polygon_clipping() { 
	rectangle(70,240,180,360);
	delay(1100);
	line(30,310,110,270);
	delay(1100);
	line(110,270,100,295);
	delay(1100);
	line(100,295,50,330);
	delay(1100);
	line(50,330,110,340);
	delay(1100);
	line(110,340,30,350);
	delay(1100);
	line(30,310,30,350);
	delay(1100);
	cleardevice();
	rectangle(70,240,180,360);
	setcolor(11);
	line(70,290,110,270);
	line(110,270,100,295);
	line(100,295,70,320);
	line(70,290,70,320);
	delay(2000);
	line(70,330,110,340);
	line(70,330,110,340);
	line(110,340,70,350);
	line(70,330,70,350);
	setcolor(15);
	getch();
}
