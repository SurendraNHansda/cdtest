#include <stdio.h>
#include <graphics.h>

void draw_bezier_curve(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
	double t, x, y;
	
	for(t = 0; t <= 1; t += 0.001) {
		x = (1-t)*(1-t)*(1-t)*x1 + 3*t*(1-t)*(1-t)*x2 + 3*t*t*(1-t)*x3 + t*t*t*x4;
		y = (1-t)*(1-t)*(1-t)*y1 + 3*t*(1-t)*(1-t)*y2 + 3*t*t*(1-t)*y3 + t*t*t*y4;
		putpixel(x, y, WHITE);
		delay(10);
	}
}

int main() {
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");
	draw_bezier_curve(10, 10, 20, 10, 40, 30, 30, 10);
	getch();
	closegraph();
	return 0;
}
