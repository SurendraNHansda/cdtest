#include <stdio.h>
#include <graphics.h>
#define OUT_OF_WINDOW -1

int X1 = 0, X2 = 0, Y1 = 0, Y2 = 0;

double max(double a, double b) {
	double m = a > b? a : b;
	return m;
}

double min(double a, double b) {
	double m = a < b? a : b;
	return m;
}

int liang_barsky(int x1, int x2, int y1, int y2, int xmin, int xmax, int ymin, int ymax) {
	int dx, dy, p[4], q[4];
	dx = x2 - x1;
	dy = y2 - y1;
	p[0] = -dx;	q[0] = x1 - xmin;
	p[1] = dx;	q[1] = xmax - x1;
	p[2] = -dy;	q[2] = y1 - ymin;
	p[3] = dy;	q[3] = ymax - y1;
	
	int k;
	double r, u1 = -10000, u2 = 10000;
	for(k = 0; k < 4; ++k) {
		if(p[k] == 0 && q[k] < 0)
			return OUT_OF_WINDOW;

		else {
			r = q[k] / (double)p[k];
			if(p[k] < 0) u1 = max(0, r);
			if(p[k] > 0) u2 = min(1, r);		
		}
	}

	if(u1 > u2)
		return OUT_OF_WINDOW;

	else if(u1 == 0) {
		X2 = x1 + u2 * dx;
		Y2 = y1 + u2 * dy;	
		return 1;	
	} 

	else {
		X1 = x1 + u1 * dx;
		Y1 = y1 + u1 * dy;
		X2 = -x1 + u2 * dx;
		Y2 = y1 + u2 * dy;
		return 2;
	}
}	

int main() {
	int x1, x2, y1, y2, xmin, ymin, xmax, ymax;
	printf("Enter the end points of the line:\n");
	scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
	printf("Enter the boundaries of the box:\n");
	scanf("%d %d %d %d", &xmin, &xmax, &ymin, &ymax);
	
	int ret_val;
	ret_val = liang_barsky(x1, x2, y1, y2, xmin, xmax, ymin, ymax);	

	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");

	line(xmin, ymin, xmin, ymax);
	line(xmin, ymin, xmax, ymin);
	line(xmax, ymin, xmax, ymax);
	line(xmin, ymax, xmax, ymax);

	if(ret_val == OUT_OF_WINDOW) printf("Line is completely outside window.\n");
	else if(ret_val == 1) line(x1, y1, X2, Y2);
	else if(ret_val == 2) line(X1, Y1, X2, Y2);

	delay(10000);
	closegraph();
	return 0;
}
