#include <stdio.h>
#include <graphics.h>

int ptr = -1;
int xstack[10000], ystack[10000];

void push(int x, int y) {
	xstack[++ptr] = x;
	ystack[ptr] = y;
}

void pop() {
	--ptr;
} 

int main() {
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");

	int int_col = 0, spec_col = RED;
	int x_seed = 40, y_seed = 22;

	line(40, 20, 20, 50);
	line(40, 20, 70, 30);
	line(70, 30, 80, 50);
	line(80, 50, 50, 40);
	line(50, 40, 20, 50);

	push(x_seed, y_seed);
	while(ptr >= 0) {
		int x, y;
		x = xstack[ptr];
		y = ystack[ptr--];
		putpixel(x,y, spec_col);
		spec_col = (spec_col + 4)%20 + 4;
		delay(10);

			push(x+1, y);
	}

	getch();
	return 0;
}
