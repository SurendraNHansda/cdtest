#include <bits/stdc++.h>
#include <graphics.h>
using namespace std;

void make_car() {
	rectangle(50, 275, 150, 400);
	rectangle(150, 350, 200, 400);
	circle(75, 410, 10);
	circle(175, 410, 10);
}

int main() {
	int gd = DETECT, gm;
	initgraph(&gd, &gm, "");
	make_car();
	return 0;
}


